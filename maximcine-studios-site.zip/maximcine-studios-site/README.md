# Maximcine Studios website

Static HTML website for the existing maximcinestudios.site hosting setup.

## Update — 8 November 2026

- Homepage: Fortress Frenzy coming-soon feature using the existing game splash artwork; Nebula Strike remains available below it.
- fortress-frenzy.html: upcoming game page. No release date, live store listing or pre-registration is claimed.
- terms-of-service.html: studio and game terms, including specific Fortress Frenzy provisions.
- Navigation, footer links, sitemap and mobile navigation updated.
- Existing CNAME, app-ads.txt, Google verification files, privacy policy links and Nebula Strike download link retained.

## Publish to your existing hosting

Extract this archive. Upload/commit the CONTENTS of this folder to the root of your existing website repository, replacing matching files and including all new HTML, CSS and the fortress-frenzy-hero.jpg image. Keep CNAME and app-ads.txt in the root. No build step or npm install is needed. Wait for your normal GitHub Pages deployment to finish.

After publishing, the new pages will be:
https://maximcinestudios.site/fortress-frenzy.html
https://maximcinestudios.site/terms-of-service.html

Use the Terms of Service URL in Play Console only after it loads publicly. The supplied ZIP does not deploy the website automatically.

## Policy review

Review the terms before publishing to ensure they match your release and actual support practices. Refund language preserves Google Play and statutory consumer rights. Review the separately hosted Privacy Policy against the final ads, purchases and online features; updating the terms does not update that external privacy page. No legal registration details, physical address or release date have been invented.
